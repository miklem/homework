import os
root = os.path.dirname(__file__)
icons = dict(
    file=os.path.join(root, 'icon_images.png'),
    folder=os.path.join(root, 'icon_folder.png'),
    config=os.path.join(root, 'icon_cog.png')

)